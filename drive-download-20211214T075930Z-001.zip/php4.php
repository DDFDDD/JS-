<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<meta charset="utf-8">
		<title>HTML Document</title>
	</head>

  	<body>
  			<?php
  				$a=5;
                $b=10;
                $c=3;
                if ($a > $b) and ($a > $c)
                {
                    echo "$a";
                }
                elseif ($b > $c) and ($b > $c)
                {
                    echo "$b";
                }
                else
                {
                    echo "$c";
                }
  			?>
	</body>

</html>