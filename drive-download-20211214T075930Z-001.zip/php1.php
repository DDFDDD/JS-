<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<meta charset="utf-8">
		<title>HTML Document</title>
	</head>

  	<body>
  			<?php
  				$myname = "SHADOW FIEND"; // выводит имя 
				$age = "18";// выводит возраст
				echo "$myname <br>";
				echo "$age";
  			?>
	</body>

</html>
