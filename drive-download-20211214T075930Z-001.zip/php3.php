<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<meta charset="utf-8">
		<title>HTML Document</title>
	</head>

  	<body>
  			<?php
  				$a=blue;// тоже самое что и в php2
                if ($a==red)
                {
                    echo "красный";
                }
                elseif ($a==blue)
                {
                    echo "синий";
                }
                else
                {
                    echo "зелёный";
                }
  			?>
	</body>

</html>
