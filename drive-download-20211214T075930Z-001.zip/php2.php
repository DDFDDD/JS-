<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<meta charset="utf-8">
		<title>HTML Document</title>
	</head>

  	<body>
  			<?php
  				$a=1;// обьявление переменной
                if ($a==1) //функция если 
                {
                    echo " а равно 1";
                    $a++;
                }
                else if ($a==0)
                {
                    echo "а равно 0";
                }
                else
                {
                    echo "а не равно 1";
                    $a--;
                }
  			?>
	</body>

</html>
