var a=4, b=2;
var result = (a*b<6) ? "Мало":"Много";
alert(result);