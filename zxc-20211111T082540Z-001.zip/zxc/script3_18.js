var chislo = prompt("Введите число");
for (var i=1; i>0; i++){
if (chislo == 50){
alert("Угадал! " + "Попыток:" + i)
}
if (chislo > 50){
	document.write("Меньше")

	var chislo = prompt("Введите число");
}
if (chislo < 50){
	document.write("Больше")

	var chislo = prompt("Введите число");
}
}