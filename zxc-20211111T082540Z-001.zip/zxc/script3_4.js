var a = 1, b = 2, max = 0;
var max = (a>b) ? a : b;
document.write(max);