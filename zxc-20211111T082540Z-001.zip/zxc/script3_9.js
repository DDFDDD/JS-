for (var sum=0, i=0; i<16; i++)
{
sum=sum+i;
document.write(sum+"<br>");
}