var name = prompt("Введите имя");
if (name == name)
{
	alert('Привет,' + name + '!');
}
