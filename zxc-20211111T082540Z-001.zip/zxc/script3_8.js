var voron = prompt("Введите количество ворон");
switch(voron){
case "1":
document.write("На ветке сидит 1 ворона");
break;
case "2":
document.write("На ветке сидит 2 вороны");
break;
case "3":
document.write("На ветке сидит 3 вороны");
break;
case "4":
document.write("На ветке сидит 4 вороны");
break;
case "5":
document.write("На ветке сидит 5 ворон");
break;
case "6":
document.write("На ветке сидит 6 ворон");
break;
case "7":
document.write("На ветке сидит 7 ворон");
break;
case "8":
document.write("На ветке сидит 8 ворон");
break;
case "9":
document.write("На ветке сидит 9 ворон");
break;
case "10":
document.write("На ветке сидит 10 ворон");
break;
default:
document.write("Ветка сломалась =)");
break}