for (var sum=0, i=0; i<16; i++)
{
sum=sum+i;
if (i==5) continue;
if (i==7) continue;
document.write(sum+"<br>");
}