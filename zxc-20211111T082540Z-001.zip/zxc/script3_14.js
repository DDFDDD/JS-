var x = prompt("Введите число");
var y = prompt("Введите степень");
 z = Math.pow(x, y);
 document.write(z)
 //Через while не смог